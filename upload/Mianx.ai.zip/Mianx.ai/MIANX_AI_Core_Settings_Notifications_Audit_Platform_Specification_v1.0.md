# MIANX.AI CORE --- SETTINGS, NOTIFICATIONS & AUDIT PLATFORM SPECIFICATION v1.0

**Product:** Mianx.ai\
**Document:** Settings, Notifications & Audit Platform\
**Version:** 1.0\
**Status:** Architecture / Pre-Implementation\
**Purpose:** Define the three shared Core services that every domain,
module, and AI agent depends on but none of them should own:
configuration, communication, and accountability.

------------------------------------------------------------------------

# 1. Purpose

Three capabilities were named repeatedly across earlier specifications
but never given their own architecture:

``` text
Settings
Notifications
Audit
```

The Domain & Module Engine Specification listed all three as things
**Core provides** to every domain. The Database & Tenancy
Specification sketched a table for each. The Security, Identity &
Governance Specification and the Observability Specification each
described a slice of Audit from their own angle.

None of that is a platform. It is scattered evidence that a platform
is needed.

This document closes that gap.

------------------------------------------------------------------------

# 2. Why These Three Belong Together

``` text
Settings      → how the system is configured
Notifications → how the system communicates
Audit         → how the system remembers what happened
```

They are grouped for the same reason Domain and Module were grouped,
and the same reason Billing and Entitlement were grouped: every domain
uses all three, none of them should implement their own version, and
they share one property.

**They are read and written by every other layer of Mianx.ai** ---
humans, workflows, and AI agents alike --- which means they must be
designed once, correctly, at Core level.

------------------------------------------------------------------------

# 3. Core Principle

``` text
Human changes a setting
      ↓
Workflow triggers a notification
      ↓
AI agent takes an action
      ↓
        ALL THREE
        PRODUCE AN
        AUDIT RECORD
```

No configuration change, no outbound communication, and no consequential
action --- human or AI --- should be invisible to the organization that
owns it.

------------------------------------------------------------------------

# 4. Relationship to Existing Specifications

This document does not replace earlier work. It completes it.

``` text
Database & Tenancy Spec
  → defined: settings, notifications, audit_logs (table shapes)

Security, Identity & Governance Spec
  → defined: security-event audit logging, audit integrity rules

Observability Spec
  → defined: audit logs vs application logs

Domain & Module Engine Spec
  → defined: domain settings, feature flags

Event, Workflow & Automation Engine Spec
  → defined: events as the trigger mechanism

THIS DOCUMENT
  → defines the platform that makes all of the above operate
    as one coherent system instead of five independent ideas
```

Where an earlier document already fixed a rule (for example, audit
records must be append-oriented), this document does not contradict
it. It builds the runtime around it.

------------------------------------------------------------------------

------------------------------------------------------------------------

# PART A --- SETTINGS PLATFORM

------------------------------------------------------------------------

# 5. Settings Model Overview

A setting is a named, typed, scoped configuration value that changes
system behavior without a code deployment.

``` text
key + scope → value
```

Settings are not:

``` text
business data        (that belongs to a domain table)
feature entitlements  (that belongs to Billing)
secrets                (that belongs to a secret store)
```

------------------------------------------------------------------------

# 6. Setting Scopes

``` text
platform
  ↓
organization
  ↓
domain
  ↓
module
  ↓
user
```

Every scope narrower than "platform" is optional. A setting only
exists at a scope if something was written there.

------------------------------------------------------------------------

# 7. Setting Resolution Order

When code asks "what is the value of X for this user, in this module,
in this domain, in this organization," the platform resolves narrowest
to broadest:

``` text
user setting exists?        → use it
  else module setting exists? → use it
    else domain setting exists? → use it
      else organization setting exists? → use it
        else platform default             → use it
          else undefined                    → error or safe fallback
```

This resolution order must be identical everywhere it is used. Ad-hoc
resolution logic inside a domain module is not permitted.

------------------------------------------------------------------------

# 8. Setting Definition

Before a setting can be written, it must be **registered**.

``` text
key
label
description
data_type
default_value
allowed_scopes[]
validation_rule
sensitive: boolean
editable_by: role[]
```

Example:

``` text
key: poultry.mortality_threshold
data_type: number
default_value: 5
allowed_scopes: [organization, domain]
validation_rule: 0 <= value <= 100
sensitive: false
editable_by: [org_admin, domain_admin]
```

------------------------------------------------------------------------

# 9. Setting Registry

Who may register a setting:

``` text
Core          → platform-wide settings
Domain        → domain-specific settings (e.g. poultry.*)
Module        → module-specific settings (e.g. poultry.feed.*)
```

A module must not register a setting outside its own namespace.

``` text
Allowed:  poultry.feed.default_unit
Rejected: billing.currency          (owned by Core)
```

------------------------------------------------------------------------

# 10. Setting Data Types

``` text
string
number
boolean
enum
json
date
duration
```

Every stored value must validate against its registered `data_type`
and `validation_rule` before being persisted.

------------------------------------------------------------------------

# 11. Setting Storage

Building on the `settings` table already sketched in the Database &
Tenancy Specification:

``` text
settings
  id
  organization_id      nullable
  scope_type            platform | organization | domain | module | user
  scope_id               nullable
  key
  value
  updated_by
  created_at
  updated_at
```

``` text
UNIQUE (organization_id, scope_type, scope_id, key)
```

The **registry** (Section 8) and the **stored value** (this section)
are two different concerns. The registry defines what is legal. This
table stores what was chosen.

------------------------------------------------------------------------

# 12. Setting Read Path

``` text
Request for setting X
      ↓
Check cache
      ↓ (miss)
Resolve scope chain (Section 7)
      ↓
Validate against registry
      ↓
Populate cache
      ↓
Return value
```

------------------------------------------------------------------------

# 13. Setting Write Path

``` text
Write request
      ↓
Authorization check
      ↓
Registry lookup
      ↓
Type + validation check
      ↓
Scope permission check
      ↓
Persist
      ↓
Invalidate cache
      ↓
Emit setting.changed event
      ↓
Write audit record
```

A setting write that is not authorized, not registered, or fails
validation must be rejected before it reaches storage.

------------------------------------------------------------------------

# 14. Setting Change Authorization

``` text
platform scope   → Mianx Super Admin only
organization scope → org_admin (or explicitly delegated role)
domain scope       → domain_admin
module scope       → module_admin / org_admin
user scope         → the user themselves, or org_admin
```

Authorization here reuses the same role/permission model defined in
the Security, Identity & Governance Specification. Settings must not
invent a parallel permission system.

------------------------------------------------------------------------

# 15. Setting Change Audit

Every setting write produces an audit record (see Part C) containing:

``` text
key
scope_type
scope_id
old_value
new_value
actor_type
actor_id
timestamp
```

Sensitive settings must audit **that a change occurred** without
necessarily storing the raw old/new value in plaintext.

------------------------------------------------------------------------

# 16. Sensitive Settings and the Secrets Boundary

``` text
Setting          → application behavior configuration
Secret            → credential, key, token
```

``` text
API key for an integration        → secret store, NOT settings
Default currency for an org        → settings, NOT secret store
Feature toggle for AI auto-approve → settings, NOT secret store
```

The Settings Platform must refuse to store a value flagged `sensitive:
true` as a plain value. It should reference a secret store entry
instead. This boundary was already established in the Security and
Data Platform specifications; this document enforces it operationally.

------------------------------------------------------------------------

# 17. Settings vs Feature Flags

These are frequently confused. They are not the same thing.

``` text
Setting        = a value           ("mortality_threshold = 5")
Feature Flag   = an on/off gate    ("advanced_ai_enabled = true")
```

Feature flags were introduced in the Domain & Module Engine
Specification (Section 32) as operating at platform / domain / module /
organization / user level --- the same scope model defined in Section 6
of this document. Feature flags are implemented as a constrained
subtype of settings:

``` text
Feature Flag
  = Setting where data_type = boolean
    and key is namespaced under `flags.*`
```

Feature flags must never be the sole gate for an authorization
decision. They control visibility and rollout, not security.

------------------------------------------------------------------------

# 18. Setting Caching Strategy

``` text
platform settings   → cache long, invalidate on admin change
organization settings → cache per-organization, invalidate on write
domain/module settings → cache per organization+domain
user settings          → cache per user session
```

Cache keys must always include tenant scope. A cache key built only
from `key` risks leaking one organization's configuration into
another's request.

------------------------------------------------------------------------

# 19. Setting History

Every setting change should be recoverable, not just auditable.

``` text
setting_history
  id
  setting_id  (or key + scope)
  old_value
  new_value
  changed_by
  changed_at
```

This allows "who changed the feed unit, and what was it before"
without reconstructing the answer from raw audit logs.

------------------------------------------------------------------------

# 20. Organization Onboarding Defaults

When an organization is created, or when a domain is activated for an
organization, the platform must seed organization-scope settings from
platform defaults:

``` text
Domain Activation (from Domain & Module Engine Spec, Section 13)
      ↓
Initialize Domain Configuration
      ↓
      THIS STEP
      ↓
For each registered domain setting:
  if no organization value exists:
    write platform default at organization scope
```

Onboarding should never leave a required setting unresolved.

------------------------------------------------------------------------

# 21. Settings API Surface

Conceptual, not final:

``` text
GET  /settings?scope=organization&key=poultry.mortality_threshold
PUT  /settings                (create/update, subject to Section 13)
GET  /settings/registry       (what settings exist and their rules)
GET  /settings/history/:key
```

All settings endpoints are tenant-scoped and pass through the same API
Gateway authentication/authorization pipeline defined in the
Integration, API & Event Platform Specification.

------------------------------------------------------------------------

------------------------------------------------------------------------

# PART B --- NOTIFICATIONS PLATFORM

------------------------------------------------------------------------

# 22. Notification Model Overview

A notification is a message delivered to a specific recipient, about a
specific thing that happened, through one or more channels.

``` text
Trigger → Template → Render → Deliver → Track
```

------------------------------------------------------------------------

# 23. Notification Channels

``` text
in_app
email
sms
push
webhook
```

A given notification type may target one channel or several. The
channel is a delivery mechanism, not the notification itself.

------------------------------------------------------------------------

# 24. Notification Triggers

Notifications are never fired directly from arbitrary business code.
They are triggered by **events**, using the event model already
defined in the Event, Workflow & Automation Engine Specification.

``` text
Domain Event (e.g. inventory.low)
      ↓
Notification Rule Match
      ↓
Notification Job Created
      ↓
Render + Deliver
```

If a domain wants to notify a user, it emits an event. It does not
call a notification service directly. This keeps notification logic
decoupled from business logic, and keeps a single audit trail of what
happened vs. what was communicated.

------------------------------------------------------------------------

# 25. Notification Types

Every notification has a registered `type`, similar to how settings
are registered.

``` text
type
label
default_channels[]
category
severity
template_key
```

Example:

``` text
type: poultry.mortality_alert
category: operational
severity: high
default_channels: [in_app, push, email]
template_key: mortality_alert_v1
```

------------------------------------------------------------------------

# 26. Notification Categories

``` text
system        (platform/account-level: password changed, invite sent)
operational    (business events: low stock, mortality spike)
approval        (something needs a human decision)
ai              (an AI agent acted, or needs approval)
billing          (invoice, payment, trial ending)
marketing         (optional, org-controlled, off by default)
```

Category drives default channel and default user preference behavior.

------------------------------------------------------------------------

# 27. Notification Templates

``` text
template_key
channel
locale
subject          (email/push)
body
variables[]
```

Rendering separates **what happened** (payload) from **how it reads**
(template), so the same event can produce a short push notification
and a longer email without duplicating trigger logic.

------------------------------------------------------------------------

# 28. Notification Localization

``` text
template_key + channel + locale → rendered content
```

If a requested locale has no template, the platform falls back to the
organization's default locale, then to a platform default locale. It
must never fail silently and produce an empty message.

------------------------------------------------------------------------

# 29. Notification Delivery Pipeline

``` text
Notification Job Queued
      ↓
Resolve Recipient(s)
      ↓
Resolve Channel Preferences (Section 30)
      ↓
Render per Channel
      ↓
Dispatch to Channel Provider
      ↓
Record Delivery Attempt
      ↓
Success → Delivered
Failure → Retry Policy (Section 35)
```

Delivery is asynchronous. A user-facing action (e.g. saving a record)
must never block on notification delivery.

------------------------------------------------------------------------

# 30. Notification Preferences

Every user controls, per category and per channel:

``` text
enabled: true/false
```

``` text
User Preferences
 ├── operational
 │    ├── in_app  → on
 │    ├── email   → on
 │    └── push    → off
 ├── approval
 │    └── all channels → on (cannot be fully disabled)
 └── marketing
      └── all channels → off by default
```

Some categories --- approval requests, security events --- must have a
minimum channel that cannot be disabled by the user, because disabling
them would create an operational or security blind spot.

------------------------------------------------------------------------

# 31. Notification Digest and Batching

High-frequency notification types should support batching:

``` text
Individual mode  → deliver immediately, one message per event
Digest mode        → accumulate over a window, deliver one summary
```

Example:

``` text
"3 flocks crossed mortality threshold in the last hour"
```

instead of three separate push notifications. Digest windows are
configurable per user, per category, using the Settings Platform
(Part A).

------------------------------------------------------------------------

# 32. Notification Priority

``` text
low        → in-app only, batched by default
normal      → in-app + email
high         → in-app + push + email
critical      → all channels, bypasses digest, bypasses quiet hours
```

Critical notifications are reserved for safety, security, and
significant financial/operational risk events, defined explicitly per
domain --- not left to developer judgment at call time.

------------------------------------------------------------------------

# 33. Notification Read State

Extending the `notifications` table already defined in the Database &
Tenancy Specification:

``` text
notifications
  id
  organization_id
  recipient_user_id
  type
  title
  body
  data
  channel
  status          queued | sent | delivered | failed | read
  read_at
  created_at
```

`read_at` applies to `in_app`. Other channels track delivery status
separately (Section 35) since "read" is not observable for SMS/email
in most cases.

------------------------------------------------------------------------

# 34. Notification Grouping

The in-app inbox should group related notifications rather than
present a flat, ever-growing list:

``` text
Flock #204
 ├── Mortality alert (2 hours ago)
 ├── Weight variance (yesterday)
 └── Feed delivery confirmed (yesterday)
```

Grouping is a presentation concern layered over the flat storage
model, not a change to how notifications are stored.

------------------------------------------------------------------------

# 35. Delivery Guarantees and Retries

``` text
Attempt 1 → fail → wait
Attempt 2 → fail → wait longer
Attempt 3 → fail → dead-letter
```

``` text
notification_delivery_attempts
  id
  notification_id
  channel
  attempt_number
  status
  provider_response
  attempted_at
```

A notification that exhausts retries is not silently dropped. It moves
to a dead-letter state, visible to the Command Center (Observability
Specification, Section 53) for operational follow-up.

------------------------------------------------------------------------

# 36. Notification Rate Limiting

Per-recipient rate limits prevent runaway automation (a misconfigured
workflow, a retry loop) from flooding a user:

``` text
max N notifications per category per hour per user
excess → automatically converted to digest
```

------------------------------------------------------------------------

# 37. Notification Multi-Tenant Isolation

``` text
notification.organization_id must match
recipient_user.organization membership
```

A notification must never be deliverable to a user outside the
organization that generated the triggering event. This is the same
tenant-isolation guarantee that applies to every other table in the
Database & Tenancy Specification, restated here because notifications
cross a system boundary (email/SMS providers) where a leak is
externally visible and harder to contain than a database leak.

------------------------------------------------------------------------

# 38. AI-Generated Notifications

An AI agent may trigger a notification the same way a workflow does:
by emitting an event, not by calling the delivery pipeline directly.

``` text
AI Agent
   ↓
agent.action.completed / agent.approval.requested
   ↓
Notification Rule Match
   ↓
Standard Delivery Pipeline
```

Every AI-triggered notification must be clearly attributable to the
acting agent in its payload, consistent with actor-attribution rules
defined for Audit (Part C).

------------------------------------------------------------------------

# 39. Notification Compliance

``` text
Unsubscribe honored immediately, per channel
Quiet hours respected for non-critical notifications
Marketing notifications require explicit opt-in
Regulatory/legal notices cannot be globally muted
```

Channel providers (email/SMS) must be configured to respect
unsubscribe/opt-out signals independently of application-level
preferences, as a second layer of protection.

------------------------------------------------------------------------

# 40. Notification Observability

Tracked per organization and per type:

``` text
sent
delivered
failed
read rate
average delivery latency
digest vs individual ratio
```

This feeds the Command Center alongside the metrics already defined in
the Observability Specification.

------------------------------------------------------------------------

------------------------------------------------------------------------

# PART C --- AUDIT PLATFORM

------------------------------------------------------------------------

# 41. Audit Model Overview

Audit is the authoritative record of **who did what, to what, and
when** --- across humans, AI agents, and the system itself.

``` text
Application Log  → for engineers, debugging
Audit Log          → for the organization, accountability
```

This distinction was already established in the Observability
Specification (Section 9). This document defines the platform that
produces, protects, and serves audit records; Observability defines
how audit data is distinguished from operational telemetry once it
exists.

------------------------------------------------------------------------

# 42. What Must Be Audited

Building on the security-event list already defined in the Security,
Identity & Governance Specification (Section 30), the Audit Platform
generalizes this into four mandatory categories:

``` text
Identity & Access   (login, role change, permission change, API key issued)
Configuration          (this document, Part A --- every setting write)
Business Action          (create/update/delete of consequential records,
                           domain-defined)
AI Action                  (every tool call, every approval, every
                           autonomous decision)
```

A domain registers which of its own business actions are
audit-worthy. Core does not attempt to guess domain-specific
significance.

------------------------------------------------------------------------

# 43. Audit Event Schema

Extending the `audit_logs` table already defined in the Database &
Tenancy Specification:

``` text
audit_logs
  id
  organization_id     nullable (platform-level actions)
  actor_type            human | ai_agent | system | integration
  actor_id
  action
  resource_type
  resource_id
  before_state           nullable
  after_state             nullable
  metadata
  correlation_id
  ip_address                nullable
  created_at
```

`before_state` / `after_state` are optional and should be populated
for configuration and business-critical changes, not for every audit
row --- storing full before/after snapshots for high-volume events would
defeat the purpose of a lean, trustworthy log.

------------------------------------------------------------------------

# 44. Actor Types

Reusing the actor model already established in the Database & Tenancy
Specification:

``` text
human        → acting user_id
ai_agent      → acting agent_id, plus the human/policy that authorized it
system          → background job, migration, scheduled task
integration       → external system acting via API key/OAuth connection
```

An audit record with an unidentifiable actor is treated as a platform
defect, not an acceptable edge case.

------------------------------------------------------------------------

# 45. Audit Event Taxonomy

Action names follow a consistent, greppable convention:

``` text
resource.action
```

Examples:

``` text
setting.changed
notification.preferences.updated
user.role.changed
api_key.created
api_key.revoked
domain.activated
module.deactivated
agent.action.executed
agent.approval.requested
agent.approval.granted
data.exported
```

This convention matches the event-naming convention already used by
the Event, Workflow & Automation Engine Specification, so audit
entries and domain events remain easy to correlate.

------------------------------------------------------------------------

# 46. Correlation

``` text
correlation_id
```

links an audit record to the request, workflow run, or agent
invocation that produced it, so a single user action that produces
several audit rows (e.g. "domain activation" produces settings writes,
module activations, and permission grants) can be reconstructed as one
story rather than read as unrelated rows.

------------------------------------------------------------------------

# 47. Audit Write Path

``` text
Action occurs
      ↓
Action handler completes (or fails, if audit-before-action is required)
      ↓
Audit record constructed
      ↓
Written to append-only store
      ↓
(optional) Emitted as event for real-time monitoring
```

For security-critical actions (permission changes, API key issuance),
the audit write should be synchronous with the action --- not queued
--- so that a crash between action and audit write cannot silently lose
the record.

For high-volume, lower-risk actions, asynchronous audit writes are
acceptable.

------------------------------------------------------------------------

# 48. Audit Integrity

Reaffirming and operationalizing the rules already set in the
Security, Identity & Governance Specification (Section 31):

``` text
append-only
no update
no hard delete
actor-attributed
tenant-scoped
timestamped
```

``` text
UPDATE audit_logs      → forbidden at the application layer
DELETE FROM audit_logs → forbidden at the application layer
```

Where regulatory data-deletion requirements require removing personal
data from an audit record, the platform must redact the specific field
rather than delete the row, and must itself audit the redaction.

------------------------------------------------------------------------

# 49. Audit Access Control

``` text
Organization Admin → can read their organization's audit log
Domain Admin           → can read audit entries scoped to their domain
Mianx Super Admin        → can read platform-wide audit data
Ordinary User               → cannot read audit logs by default
```

**Reading** audit data is itself an audited action (Section 42,
Identity & Access category), matching the rule already stated in the
Security Specification: administrative access to audit data must
itself be audited.

------------------------------------------------------------------------

# 50. Audit Retention

``` text
Security-critical audit categories   → long retention, regulatory-driven
Business action audit                  → organization-configurable,
                                             with a platform-enforced minimum
AI action audit                          → long retention (governance,
                                             dispute resolution)
```

Retention periods are a setting (Part A), scoped at platform level with
an organization-level override ceiling --- an organization may extend
retention but not shorten it below the platform-enforced minimum.

------------------------------------------------------------------------

# 51. Audit Export

``` text
GET /audit-logs?filters...&format=csv|json
```

Exports are themselves audited (`data.exported`) and rate-limited, to
prevent a compromised admin session from silently exfiltrating the
entire audit history in one call.

------------------------------------------------------------------------

# 52. AI Action Auditing

Every AI agent action produces an audit record containing:

``` text
agent_id
tool_used
input_summary
output_summary
permission_used
human_approval_id      nullable
cost                      nullable
correlation_id
```

This is the same principle already established across the AI Engine &
Agent Runtime and AI Platform & Agent Operating System Specifications
("AI Audit"): this document is where that per-domain AI audit data
lands, is stored consistently, and becomes queryable alongside human
audit activity --- not a separate, disconnected log.

------------------------------------------------------------------------

# 53. Audit and Application Logs Boundary

Restating the Observability Specification's distinction in
implementation terms:

``` text
"Payment webhook returned 500"        → application log
"Org admin changed the payment plan"    → audit log
"AI agent retried a tool call 3 times"    → application log
"AI agent approved a $10,000 purchase"     → audit log
```

The test: **would the organization reasonably want to know this
happened, independent of whether anything went wrong?** If yes, it is
audit. If it only matters when something breaks, it is application
logging.

------------------------------------------------------------------------

------------------------------------------------------------------------

# PART D --- CROSS-CUTTING PLATFORM RULES

------------------------------------------------------------------------

# 54. Multi-Tenant Isolation Summary

All three services share one non-negotiable rule, already established
platform-wide in the Database & Tenancy Specification:

``` text
organization_id is not optional context.
It is part of every query, every cache key, every delivery target,
and every audit record.
```

``` text
Settings        → resolved within organization scope chain
Notifications      → delivered only within organization membership
Audit                 → readable only within organization boundary
```

------------------------------------------------------------------------

# 55. Permission Model

None of the three services define their own authorization system.
All three consume the role/permission model defined in the Security,
Identity & Governance Specification:

``` text
settings.read
settings.write
settings.write.platform      (Super Admin only)
notifications.manage
notifications.send.marketing
audit.read
audit.read.platform             (Super Admin only)
audit.export
```

------------------------------------------------------------------------

# 56. Domain and Module Integration

A domain integrates with this platform the same way it integrates
with every other Core service --- through its manifest (Domain & Module
Engine Specification, Section 6):

``` text
manifest
{
  settings[]        → registered settings this domain owns
  notification_types[] → registered notification types
  audit_actions[]        → business actions this domain wants audited
}
```

Core validates the manifest at domain publication time (Domain &
Module Engine Specification, Section 35 Security Checklist) and
rejects a manifest that tries to register a setting, notification
type, or audit action outside the domain's own namespace.

------------------------------------------------------------------------

# 57. Command Center Integration

The Mianx Command Center (introduced in the Architecture Specification
and expanded in the Observability Specification) surfaces all three
services:

``` text
Command Center
 ├── Settings
 │    └── platform defaults, per-organization overrides
 ├── Notifications
 │    └── delivery health, dead-lettered messages, digest volume
 └── Audit
      └── platform-wide audit search, export, integrity status
```

Super Admin visibility into these three services must itself remain
audit-logged, per Section 49.

------------------------------------------------------------------------

# 58. Testing Requirements

``` text
□ Setting resolution order test (all five scopes)
□ Setting validation rejects out-of-range / wrong-type values
□ Sensitive setting cannot be written as plaintext
□ Cross-tenant setting read/write is rejected
□ Notification preference correctly suppresses/allows delivery
□ Critical notification bypasses digest and quiet hours
□ Cross-tenant notification delivery is rejected
□ Failed delivery reaches dead-letter after max retries
□ Audit record is created for every mandatory category (Section 42)
□ Audit record cannot be updated or hard-deleted via application code
□ Cross-tenant audit read is rejected
□ AI agent actions produce complete audit records
□ Audit access itself produces an audit record
```

------------------------------------------------------------------------

# 59. Definition of Done

``` text
✓ Setting registry implemented, scope resolution implemented
✓ Sensitive setting / secret boundary enforced
✓ Notification triggers wired to the Core event bus
✓ Notification templates support multi-channel + localization
✓ Delivery pipeline implemented with retry + dead-letter
✓ User notification preferences implemented and enforced
✓ Audit write path implemented for all four mandatory categories
✓ Audit integrity constraints enforced at the database layer
✓ Audit read access restricted and itself audited
✓ Domain manifest validation covers settings/notifications/audit
✓ Command Center surfaces all three services
✓ Full test matrix (Section 58) passing
```

------------------------------------------------------------------------

# 60. Final Principle

> **A system a human cannot configure is rigid. A system that cannot
> tell a human what happened is unaccountable. A system that forgets
> is unsafe to automate.**

``` text
SETTINGS
   +
NOTIFICATIONS
   +
AUDIT
   =
A PLATFORM AN ORGANIZATION CAN TRUST WITH AUTOMATION
```

Every domain built on Mianx.ai --- Poultry first, others after ---
inherits this trust for free. No domain should ever need to build its
own configuration system, its own alerting system, or its own
accountability log.

------------------------------------------------------------------------

# 61. Next Technical Deliverable

Next:

# MIANX.AI CORE --- COMMAND CENTER, TESTING & PRODUCTION READINESS SPECIFICATION v1.0

It will define:

-   The Mianx Command Center as a first-class Super Admin application
-   Platform-wide, tenant, and domain health views
-   The full Core testing strategy (unit, integration, security,
    tenant-isolation, load)
-   Staging vs production environment strategy
-   Go-live checklist for Mianx Core itself
-   Go-live checklist for a new domain (Poultry first)
-   Incident response process
-   Rollback strategy

Once this is complete, the Core specification set (Identity through
Operations) is closed, and the next document begins actual domain work:

# MIANX POULTRY OS --- DOMAIN SPECIFICATION v1.0
